from django.urls import path,re_path
from . import views

urlpatterns = [
    path('logintest/', views.LoginView.as_view()),
    path('guanli/', views.GuanliApiview.as_view()),
    re_path('guanli/(?P<pk>\d+)/', views.GuanlidetailApiview.as_view()),
    path('cs/', views.Csview.as_view()),
    re_path('cs/(?P<pk>\d+)/', views.Csdetailview.as_view()),
    path('gm/', views.Gmview.as_view()),
    re_path('gm/(?P<pk>\d+)/', views.Gmdetailview.as_view()),
    path('jq/', views.Jqview.as_view()),
    re_path('jq/(?P<pk>\d+)/', views.Jqdetailview.as_view()),
    # 订单管理
    path('dd/', views.Ddview.as_view()),
    re_path('dd/(?P<pk>\d+)/', views.Dddetailview.as_view()),
]