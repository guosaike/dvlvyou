from django.db import models

# Create your models here.

# 管理表
class Guanli(models.Model):
    username = models.CharField(max_length=255)
    password = models.TextField()

# 风景区发布人
class Chushou(models.Model):
    # 姓名
    username = models.CharField(max_length=255,null=True,blank=True,unique=True)
    # 密码
    password = models.CharField(max_length=255,null=True,blank=True)
    img_url = models.CharField(max_length=255, null=True, blank=True)
    # 简介
    jianjie = models.CharField(max_length=255, default='个人旅游', null=True, blank=True)

# 风景区买票人
class Goumai(models.Model):
    # 姓名
    username = models.CharField(max_length=255,null=True,blank=True,unique=True)
    # 密码
    password = models.CharField(max_length=255,null=True,blank=True)
    img_url = models.CharField(max_length=255, null=True, blank=True)
    # 简介
    jianjie = models.CharField(max_length=255,default='南京旅游发布',null=True,blank=True)


# 景区
class Jingqu(models.Model):
    name = models.CharField(max_length=255) # 景点名称
    price = models.IntegerField() # 景点价格
    dizhi = models.CharField(max_length=255, null=True, blank=True) # 景点地址
    dengji = models.CharField(max_length=255, null=True, blank=True) # 景点等级
    img_url = models.CharField(max_length=255,null=True,blank=True) # 景点照片
    jianjie = models.TextField() # 景点简介
    zhuangtai = models.CharField(max_length=255, null=True, blank=True, default='待上架') # 上架状态
    is_kaifang = models.CharField(max_length=255, null=True, blank=True, default='开放中') # 开放状态
    is_shenhe = models.CharField(max_length=255, null=True, blank=True, default='待审核') # 审核状态
    maijia = models.ForeignKey(Chushou, on_delete=models.CASCADE) # 景点发布人
    collect_num = models.CharField(max_length=255, null=True, blank=True, default='30') # 浏览量

class Dingdan(models.Model):
    # 买家
    shui = models.ForeignKey(Goumai, on_delete=models.CASCADE)
    # 什么时间
    gmsj = models.DateField(null=True,blank=True)
    # 卖家
    maijia = models.CharField(max_length=255, null=True, blank=True,default='cs1')
    # 买的哪个商品
    title = models.CharField(max_length=255, null=True, blank=True)
    # 图片
    img_url = models.CharField(max_length=255, null=True, blank=True)
    # 价格
    price = models.FloatField()
    # 支付状态
    zfzt = models.CharField(max_length=255, null=True, blank=True,default='待支付')
    phone = models.CharField(max_length=255, null=True, blank=True,default='')
    addr = models.CharField(max_length=255, null=True, blank=True,default='')